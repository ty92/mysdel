#include <linux/init.h>
#include <linux/module.h>

#include <linux/kernel.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/syscalls.h>
#include <linux/time.h>

#include <asm/unistd.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Lorenzo Colitti <lorenzo@colitti.com>");

unsigned long **sys_call_table = (unsigned long **)0xffffffff81801400;
void (*unlink)(int f, const void *buf, size_t n);

/* Stolen from scprint.c
 * http://downloads.securityfocus.com/downloads/scprint.tar.gz
 */
unsigned long **find_sys_call_table(void) {
    unsigned long **sctable;
    unsigned long ptr;
    extern int loops_per_jiffy;

    sctable = NULL;
    for (ptr = (unsigned long)&loops_per_jiffy;
        ptr < (unsigned long)&boot_cpu_data; ptr += sizeof(void *)){
    
        unsigned long *p;
        p = (unsigned long *)ptr;
        if (p[__NR_close] == (unsigned long) sys_close){
            sctable = (unsigned long **)p;
            return &sctable[0];
        }
    }

    return NULL;
}

int make_rw(unsigned long address)
{
        unsigned int level;
        pte_t *pte = lookup_address(address, &level);//查找虚拟地址所在的页表地址
    //设置页表读写属性
        pte->pte |=  _PAGE_RW;

        return 0;
}
/* make the page write protected */
int make_ro(unsigned long address)
{
        unsigned int level;
        pte_t *pte = lookup_address(address, &level);
        pte->pte &= ~_PAGE_RW; //设置只读属性

        return 0;
}

void loggingread(int fd, const void *buf, size_t n) {
	printk(KERN_INFO "seccuss\n");
	printk(KERN_INFO "seccuss\n");
	printk(KERN_INFO "seccuss\n");
}

static int __init readlog_init(void) {
//    sys_call_table = find_sys_call_table();
	printk(KERN_INFO "Loading readlog module, sys call table at %p\n", sys_call_table);
    unlink = (void *) (sys_call_table[__NR_unlink]);
    make_rw((unsigned long)sys_call_table); 
    sys_call_table[__NR_unlink] = (void *) loggingread;
    make_ro((unsigned long)sys_call_table);

	return 0;
}

static void __exit readlog_exit(void) {
	printk(KERN_INFO "Unloading readlog module\n");
    make_rw((unsigned long)sys_call_table);
    sys_call_table[__NR_unlink] = (void *) unlink;
    make_ro((unsigned long)sys_call_table);
}

module_init(readlog_init);
module_exit(readlog_exit);
